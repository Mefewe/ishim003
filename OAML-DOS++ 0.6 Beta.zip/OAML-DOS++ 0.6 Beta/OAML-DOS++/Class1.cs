﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Upek;
namespace OAML_DOS__
{
    class Disk
    {
        string[] Disk_ = new string[900];
        
        string DirAdd(string name)
        {
            Disk_[0] = "**";
            return "1";
        }
        string Dir(string[] disk)
        {

            return "0";
        }

    }
}
